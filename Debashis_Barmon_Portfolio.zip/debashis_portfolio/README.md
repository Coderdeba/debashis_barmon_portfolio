# Debashis Barmon — Portfolio Website

A responsive personal portfolio built with HTML, custom CSS, Tailwind CSS (CDN), and vanilla JavaScript.

## Files
- `index.html` — page structure and content
- `styles.css` — custom styling and responsive layouts
- `script.js` — mobile navigation and dynamic footer year
- `assets/Debashis_Barmon_CV.pdf` — downloadable CV

## Run locally
Open `index.html` in a modern browser. An internet connection is needed for Tailwind CDN, Google Fonts, and the externally hosted profile image.

## Before publishing
1. Confirm that the Facebook-hosted profile image URL is still publicly accessible. If it expires or is blocked, download the photo and place it in `assets/profile.jpg`, then update the `src` of `.profile-photo` in `index.html` to `assets/profile.jpg`.
2. Replace the CV PDF in `assets/` if a newer public version is prepared.
3. Review all contact details before deployment.

## Deploy
Upload the contents of this folder to Cloudflare Pages, Netlify, Vercel, or any static hosting provider.
